import cv2
import threading
#from models.model_inference import run_inference
from backend.models.model_inference import run_inference



class VideoStream:
    def __init__(self, source, stream_id):
        self.source = source
        self.stream_id = stream_id
        self.cap = cv2.VideoCapture(source)
        self.frame = None
        self.running = True
        self.results = []

    def start(self):
        threading.Thread(target=self.update, daemon=True).start()
        return self

    def update(self):
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                break
            self.frame = frame

            # Run AI inference
            self.results = run_inference(frame)

    def get_results(self):
        return self.results

    def stop(self):
        self.running = False
        self.cap.release()
