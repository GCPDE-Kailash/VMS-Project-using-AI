from ultralytics import YOLO
import torch

# Load YOLO model (pretrained COCO)
model = YOLO("yolov8n.pt")  # lightweight version

def run_inference(frame):
    results = model(frame)  # Run YOLO
    objects = []
    for result in results:
        for box in result.boxes:
            label = model.names[int(box.cls)]
            confidence = float(box.conf)
            objects.append({"label": label, "confidence": confidence})
    return objects
