from fastapi import FastAPI
#from utils.video_handler import VideoStream
from backend.utils.video_handler import VideoStream


app = FastAPI()

streams = {}  # store active streams

@app.post("/start_stream")
def start_stream(stream_id: str, source: str):
    if stream_id in streams:
        return {"message": f"Stream {stream_id} already running"}
    stream = VideoStream(source, stream_id).start()
    streams[stream_id] = stream
    return {"message": f"Stream {stream_id} started"}

@app.get("/get_frame/{stream_id}")
def get_frame(stream_id: str):
    stream = streams.get(stream_id)
    if stream and stream.get_frame() is not None:
        return {"stream_id": stream_id, "status": "Frame received"}
    return {"error": "Stream not running or no frame"}

@app.post("/stop_stream/{stream_id}")
def stop_stream(stream_id: str):
    stream = streams.pop(stream_id, None)
    if stream:
        stream.stop()
        return {"message": f"Stream {stream_id} stopped"}
    return {"error": "Stream not found"}

# @app.get("/get_results/{stream_id}")
# def get_results(stream_id: str):
#     stream = streams.get(stream_id)
#     if stream:
#         return {"stream_id": stream_id, "results": stream.get_results()}
#     return {"error": "Stream not found"}

results_store = {}

@app.get("/get_results/{stream_id}")
def get_results(stream_id: str):
    stream = streams.get(stream_id)
    if stream:
        results_store[stream_id] = stream.get_results()  # store latest results
        return {"stream_id": stream_id, "results": stream.get_results()}
    return {"error": "Stream not found"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
