video-management-system/
│
├── backend/              # Flask/FastAPI backend
│   ├── app.py
│   ├── models/           # AI model scripts
│   ├── utils/            # Helper functions (video, inference)
│   └── requirements.txt
│
├── frontend/             # React dashboard
│   ├── src/
│   ├── package.json
│
└── README.md             # Setup instructions

python -m venv venv
venv\Scripts\activate
pip install fastapi uvicorn opencv-python pillow numpy torch torchvision
python -m uvicorn app:app --reload
