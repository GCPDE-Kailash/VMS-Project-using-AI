import React, { useEffect, useState } from "react";
import axios from "axios";

function Dashboard() {
  const [streams, setStreams] = useState(["cam1"]); // list of stream IDs
  const [results, setResults] = useState({});

  useEffect(() => {
    const interval = setInterval(() => {
      streams.forEach((id) => {
        axios.get(`http://127.0.0.1:8000/get_results/${id}`).then((res) => {
          setResults((prev) => ({ ...prev, [id]: res.data.results }));
        });
      });
    }, 2000); // fetch every 2 seconds

    return () => clearInterval(interval);
  }, [streams]);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Video Management Dashboard</h2>
      {streams.map((id) => (
        <div key={id} style={{ margin: "20px", border: "1px solid #ccc", padding: "10px" }}>
          <h3>Stream: {id}</h3>
          <p>AI Detections:</p>
          <ul>
            {results[id]?.map((obj, index) => (
              <li key={index}>{obj.label} ({(obj.confidence * 100).toFixed(2)}%)</li>
            )) || <li>No results yet</li>}
          </ul>
        </div>
      ))}
    </div>
  );
}

export default Dashboard;
